"""Format the sweep estimates for reading and manuscript editing."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
result = json.loads((root/"summary.json").read_text(encoding="utf-8"))
rows = result["rows"]
def name(row):
    return "Smooth SEED Joint" if row["condition"] == "joint" else row["condition"] + "%"

def contrast(row, endpoint, digits):
    value = row[f"{endpoint}_aa_minus_direct"]
    low, high = (row[f"{endpoint}_ci95_{k}"] for k in ("lo","hi"))
    return f"{value:+.{digits}f} [{low:+.{digits}f}, {high:+.{digits}f}]"

def scores(row, endpoint, digits):
    mean = "/".join(f"{row[f'{endpoint}_{mode}']:.{digits}f}" for mode in ("direct","antialias"))
    return f"{mean} · {contrast(row, endpoint, digits)}"

content = [
    "# SEED mains–EMG sweep",
    "",
    "All rows use 15 participants and 0 dB broadband calibration. Cells give Direct/AA means followed by AA minus Direct and its pointwise 95% paired participant-bootstrap interval. Each percentage denotes the nominal Direct mains share of broadband component power before mixing.",
    "",
    "## Delivered Beta exposure and feature error",
    "",
    "| Mains share | Direct Beta harmonic share (%) | AA Beta harmonic share (%) | Beta SNR (dB) | Beta BDE error (bit) |",
    "| --- | ---: | ---: | --- | --- |",
]
for r in rows:
    content.append(f"| {name(r)} | {r['harmonic_beta_pct_direct']:.3f} | {r['harmonic_beta_pct_antialias']:.6f} | {scores(r,'beta_snr_db',2)} | {scores(r,'bde_error_bit',4)} |")
clean = result["clean_balanced_accuracy_pct"]
content.extend([
    "",
    "## Fixed-decoder sensitivity",
    "",
    f"Clean balanced accuracy was {clean['45']:.2f}% at 45 Hz and {clean['49']:.2f}% at 49 Hz. The interaction is the 45 Hz AA advantage minus the 49 Hz AA advantage.",
    "",
    "| Mains share | Balanced accuracy at 45 Hz (%) and difference (pp) | Balanced accuracy at 49 Hz (%) and difference (pp) | Interaction (pp) |",
    "| --- | --- | --- | --- |",
])
for r in rows:
    content.append(f"| {name(r)} | {scores(r,'balanced_accuracy_45_pct',2)} | {scores(r,'balanced_accuracy_49_pct',2)} | {contrast(r,'edge45_minus_edge49_pp',2)} |")
content.extend(["", "Pointwise intervals are descriptive. The CSV and JSON supply Bonferroni intervals for each seven-point endpoint family. The full Joint replay serves as a reference outside the grid.", ""])
(root/"results.md").write_text("\n".join(content), encoding="utf-8")

