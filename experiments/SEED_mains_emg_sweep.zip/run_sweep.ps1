param([switch]$Pilot)
$env:PYTHONDONTWRITEBYTECODE='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:MKL_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$revision='D:/aaa/Sensors_EEG_FinalProof_20261126'
$deps='D:/aaa/tmp/sensors-table-audit-20261126/instantaneous_replay'
$snapshot=Get-ChildItem 'D:/aaa/tmp/sensors-round2-lineage-20261126/snapshot' -Directory | Select-Object -First 1
$opts=@()
if ($Pilot) { $opts+= '--pilot' }
python -u "$PSScriptRoot/mains_emg_sweep.py" --aligned "$revision/aligned_protocol" --dependencies $deps --code "$($snapshot.FullName)/emg_release/analysis" --data 'D:/SCI_EEG_DATA/SEED/SEED/Preprocessed_EEG' --epochs 'D:/aaa/tmp/sensors_round2_inputs' --emg 'D:/aaa/PaperB_Sensors_EMG_20261121/inputs/EMG_all_epochs_512hz.mat' --mapping "$deps/verified_epoch_map.npy" --geometry "$deps/seed_geometry.csv" --out $PSScriptRoot --workers 8 @opts
exit $LASTEXITCODE
