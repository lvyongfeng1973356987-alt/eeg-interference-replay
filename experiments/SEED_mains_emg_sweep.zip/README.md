# SEED mains–EMG sweep

## Protocol

The sweep uses the 200 Hz SEED release, the same 60 s crops and 128 Hz resampling as the archived Smooth SEED Joint benchmark, a 1 Hz clean-input high-pass, full-trial zero-phase band filtering, and a 0 dB broadband calibration on each noisy synthesis path. It uses the seeded AR(1) timing control (20261122), smooth scalp gains, the same matched 512 Hz EMG bank and zero-lag projections as the benchmark. The seven sweep conditions contain line and EMG. An eighth condition reproduces the full Smooth SEED Joint recipe as a reference, outside the seven-point grid.

For each trial/draw, scale the Direct line and EMG to unit broadband power. Normalize the AA line by the *same* Direct line denominator, preserving the FIR's attenuation before 0 dB mixture calibration. Multiply line and EMG by the square roots of the nominal fractions and sum, then match the whole mixture's broadband power to clean EEG separately for each path. The nominal horizontal coordinate is the target Direct line share in the sum of component powers, excluding their signed cross term. The realized Beta harmonic share is the mean square of the separately filtered harmonic component divided by the mean square of the complete interference, using the same centered late windows. The numerator covers the 100 and 150 Hz harmonics with their path-specific amplitudes and folding. Residual 50 Hz leakage is included in the denominator.

All mixture fractions, Direct/AA and band edges use the same test trials, phases and EMG draws. Windows are 512 samples with a 117-sample step, and the first 640 samples supply the BDE reference. The decoder uses clean-only four-group selection within each LOSO fit and Session 1 centering through the pinned SVM implementation. It fits one model per subject and edge and reuses that model across all conditions at that edge. Only the upper descriptor band changes between 45 and 49 Hz. The sweep's 100% line endpoint uses the smooth, seeded and continuously filtered scan protocol, so it is a distinct replay from the historical isolated-mains table.

## Outputs

- `summary.csv` and `summary.json` contain the mean exposure and scores for each arm, paired differences and their intervals. Differences are AA minus Direct, except the edge interaction, which subtracts the 49 Hz AA advantage from the 45 Hz advantage.
- `participant_metrics.csv` and `trial_metrics.csv` provide the input to participant-level summaries. The per-edge directories contain trial predictions and clean model selections.
- `mains_emg_sweep.pdf` and `mains_emg_sweep.png` show the three endpoint families. Error bars display pointwise paired percentile intervals from 20,000 bootstrap draws of 15 participants. The summary also supplies conservative two-sided 95% Bonferroni paired t intervals across the seven grid points, separately by endpoint.
- `validation.json` compares the full Joint reference with the archived BDE, beta exposure and decoder ledgers and checks the 0% mains endpoint.

The pointwise and simultaneous intervals describe differences at the tested grid points. Estimating a continuous change point would require denser sampling and a model for the dose–response curve. The measured fraction and detection limit depend on the spectrum, reconstructions, participant sample and chosen endpoint.

## Repeat

Use the licensed SEED and EEGdenoiseNet inputs, the existing manuscript's `aligned_protocol` and `instantaneous_replay` directories, and the source snapshot at commit `6d5edcf11697e1c4e3ec1cbe7a601524f028a0a6` of `eeg-interference-replay`. `run_sweep.ps1` records the local input paths. `mains_emg_sweep.py --help` shows the portable entry point. Limit BLAS threads to one per process. Use a fresh output directory if any data, parameters or code change, because the driver reuses complete participant caches. `plot_sweep.py` reads the summary from its directory. The raw EEG and artifact banks are external to these result files.


Runtime: Python 3.12.10, NumPy 2.4.4, SciPy 1.17.1, pandas 3.0.2, scikit-learn 1.8.0, Matplotlib 3.10.8.
