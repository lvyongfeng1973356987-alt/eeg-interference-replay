"""Validate sweep ledgers against the same-data published Smooth SEED Joint replay."""
from pathlib import Path
import argparse
import json

import numpy as np
import pandas as pd


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("sweep", "aligned-results", "bde-ledger"):
        parser.add_argument("--"+name, type=Path, required=True)
    a = parser.parse_args()
    keys = ["subject", "session", "trial", "draw", "mode"]
    trials = pd.read_csv(a.sweep/"trial_metrics.csv", dtype={"condition":str})
    joint = trials[trials.condition.eq("joint")].set_index(keys)
    archived = pd.read_csv(a.aligned_results/"smooth_metrics.csv").set_index(keys)
    assert set(joint.index) == set(archived.index)
    q = joint.join(archived, validate="one_to_one")
    beta_diff = q.beta_snr_db-q.beta_snr
    harmonic_diff = q.harmonic_beta_pct-100*q.harmonic/q.total
    np.testing.assert_allclose(beta_diff, 0, atol=1e-10)
    np.testing.assert_allclose(harmonic_diff, 0, atol=5e-8)

    bde = pd.read_csv(a.bde_ledger)
    bde = bde[(bde.timing=="seeded") & (bde.setting=="smooth_no_pulse") & (bde.comparison=="antialias")].copy()
    bde["mode"] = bde.arm.replace({"aa":"antialias"})
    bde = bde.set_index(keys)
    assert set(bde.index) == set(joint.index)
    bde_diff = joint.bde_error_bit-bde.bde
    np.testing.assert_allclose(bde_diff, 0, atol=2e-7)

    scan = pd.read_csv(a.sweep/"edge_49/trial_predictions.csv")
    control = pd.read_csv(a.aligned_results/"smooth/trial_predictions.csv")
    scan = scan[scan.synthesis.str.startswith("joint_") | scan.synthesis.eq("clean")].copy()
    scan["synthesis"] = scan.synthesis.str.removeprefix("joint_")
    pkeys = ["protocol", "subject", "session", "trial", "label", "realization", "snr_db", "synthesis"]
    checked = scan.set_index(pkeys).join(control.set_index(pkeys), rsuffix="_archived", validate="one_to_one")
    assert len(checked) == len(control) == 2250
    np.testing.assert_array_equal(checked.prediction, checked.prediction_archived)

    selections = "clean_inner_selection.csv"
    selection_keys = ["protocol", "outer_subject", "feature", "kernel", "C"]
    selected = pd.read_csv(a.sweep/"edge_49"/selections)
    archived_selection = pd.read_csv(a.aligned_results/"smooth"/selections)
    pd.testing.assert_frame_equal(selected[selection_keys], archived_selection[selection_keys])

    for edge in (45,49):
        p = pd.read_csv(a.sweep/f"edge_{edge}/trial_predictions.csv")
        p = p[p.synthesis.isin(["0_direct","0_antialias"])]
        assert len(p) == 1800
        w = p.pivot(index=["subject","session","trial","realization"], columns="synthesis",values="prediction")
        np.testing.assert_array_equal(w["0_direct"], w["0_antialias"])

    result = {
        "matched_published_joint_metric_rows": len(q),
        "max_abs_beta_snr_delta_db": float(beta_diff.abs().max()),
        "max_abs_harmonic_beta_share_delta_pct": float(harmonic_diff.abs().max()),
        "max_abs_bde_error_delta_bit": float(bde_diff.abs().max()),
        "matched_published_joint_predictions_at_49": len(checked),
        "emg_only_arms_identical_on_both_edges": True,
    }
    print(json.dumps(result, indent=2))
    (a.sweep/"validation.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()

