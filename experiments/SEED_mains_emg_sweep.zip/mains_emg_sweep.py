"""SEED paired mains/EMG dose sweep, using the archived clean-only decoder."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from pathlib import Path
import json
import re
import sys

import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.signal import resample_poly

GRID = (0, 10, 25, 50, 75, 90, 100)
CONDITIONS = tuple(map(str, GRID)) + ("joint",)
MODES = ("direct", "antialias")
EDGES = (45, 49)


def initialize(aligned, dependencies, code, epochs, emg, mapping, geometry):
    global replay, j, n, cases, filters
    sys.path[:0] = [str(aligned), str(dependencies)]
    import replay
    replay.initialize(code, epochs, emg, mapping, None, geometry)
    n = replay.n
    j = n.replay.j
    cases = [(draw, 0, condition + "_" + mode)
             for draw in j.REALIZATIONS for condition in CONDITIONS for mode in MODES]
    filters = {band: j.filter_design(band).astype("float64")
               for band in [*j.BANDS, (31, 45)]}
    filters[(14, 31)] = n.replay.SOS


def components(case):
    """Reuse the smooth Joint draw order to share its epochs and phases."""
    subject, session, trial, draw = case
    f = n.replay.f
    rng = np.random.default_rng(np.random.SeedSequence([j.BASE_SEED, draw, subject, session, trial]))
    control = replay.primary.controls["seeded"]
    offset = rng.integers(len(control) - j.T + 1)
    env = control[offset:offset + j.T]
    phase = rng.uniform(0, 2*np.pi, 3)
    _, drift, _ = replay.primary.drift_pair(f, env, rng)
    white = .1*rng.standard_normal((len(j.CHANNELS), j.T), dtype="float32")
    jitter = rng.uniform(.7, 1, len(j.CHANNELS))
    index = (np.exp(-.2*np.abs(np.arange(len(j.CHANNELS))-len(j.CHANNELS)//2))*jitter).astype("float32")[:, None]
    gain = (n.spatial*jitter).astype("float32")[:, None]
    gain *= np.float32(np.sqrt(f.power(index)/f.power(gain)))
    eye = replay.primary.artifact_pair(j, n.epochs[0], j.EOG, rng)[0]
    emg = replay.primary.artifact_pair(j, n.epochs[1], j.EMG, rng)[0]
    tones = [f.components(env, phase, aa) for aa in (False, True)]
    line = [gain*t.sum(axis=0) for t in tones]
    harmonic = [gain*t[1:].sum(axis=0) for t in tones]
    joint = []
    for tone, harmonics in zip(tones, harmonic, strict=True):
        combined = gain*(tone.sum(axis=0)+(drift+white))
        wave = (.5*f.unit_noise(combined)+np.sqrt(.4)*eye)+np.sqrt(.35)*emg
        joint.append((wave, (.5/np.sqrt(f.power(combined)))*harmonics))
    denominator = np.sqrt(f.power(line[0]))
    return [x/denominator for x in line], [x/denominator for x in harmonic], emg, joint


def spectral_features(signal, filtered_beta=None):
    descriptors = []
    for band, sos in filters.items():
        filtered = filtered_beta if band == (14, 31) and filtered_beta is not None else n.apply(sos, signal)
        logvar = j.half_logvar(np.var(j.spans(filtered), axis=-1))
        reference = j.half_logvar(np.var(filtered[:, :j.REF], axis=-1))
        descriptors.append(j.descriptors(logvar, reference, filtered))
    return {edge: tuple(np.concatenate([*parts[:3], parts[upper]]).astype("float32")
                        for parts in zip(*descriptors, strict=True))
            for edge, upper in ((45, 4), (49, 3))}


def score(clean, beta_clean, beta_snr_power, bde_clean, wave, harmonics, harmonic_beta_power=None):
    gain = j.amount(clean, wave, 0)
    filtered = n.apply(filters[(14, 31)], clean + gain*wave)
    noise_beta = n.apply(filters[(14, 31)], wave)
    noise_power = j.power(j.centered(j.spans(noise_beta)))
    if harmonic_beta_power is None:
        harmonic_beta = n.apply(filters[(14, 31)], harmonics)
        harmonic_beta_power = j.power(j.centered(j.spans(harmonic_beta)))
    stimulus = j.half_logvar(np.var(j.spans(filtered), axis=-1))
    reference = j.half_logvar(np.var(filtered[:, :j.REF], axis=-1))
    bde = float(np.mean(np.abs(stimulus-reference[:, None]-bde_clean), dtype="float64"))
    beta_snr = 10*np.log10(beta_snr_power/(gain**2*noise_power))
    broadband = 10*np.log10(j.power(clean)/j.power(gain*wave))
    metrics = 100*harmonic_beta_power/noise_power, beta_snr, bde, broadband
    return metrics, spectral_features(clean+gain*wave, filtered)


def participant(data, cache, subject, trial_limit=None):
    dest = cache / f"subject_{subject:02d}.npz"
    if dest.is_file():
        return subject
    files = sorted(p for p in data.glob(f"{subject}_*.mat") if re.fullmatch(r"\d+_\d+\.mat", p.name))
    labels = loadmat(data/"label.mat")["label"].ravel().astype(int)
    assert len(files) == 3 and len(labels) == 15
    meta, records = [], []
    storage = {edge: [[], [], []] for edge in EDGES}
    for session, file in enumerate(files, 1):
        mat = loadmat(file)
        for trial, label in enumerate(labels[:trial_limit], 1):
            eeg = next(v for k, v in mat.items() if re.search(rf"eeg{trial}$", k))
            raw = resample_poly(eeg[:, :12000].astype("float32"), 16, 25, axis=-1)
            clean = n.apply(n.highpass, raw).astype("float32")
            beta = n.apply(filters[(14, 31)], clean)
            beta_power = j.power(j.centered(j.spans(beta)))
            clean_bde = j.half_logvar(np.var(j.spans(beta), axis=-1)) - j.half_logvar(
                np.var(beta[:, :j.REF], axis=-1))[:, None]
            features = {edge: [bundle] for edge, bundle in spectral_features(clean, beta).items()}
            meta.append((subject, session, trial, label))
            if session != 1:
                for draw in j.REALIZATIONS:
                    case = (subject, session, trial, draw)
                    line, harmonic, emg, joint = components(case)
                    hpower = [j.power(j.centered(j.spans(n.apply(filters[(14, 31)], h)))) for h in harmonic]
                    for condition in CONDITIONS:
                        for arm, mode in enumerate(MODES):
                            if condition == "joint":
                                wave, harmonics = joint[arm]
                                result, vectors = score(clean, beta, beta_power, clean_bde, wave, harmonics)
                            elif condition == "0" and arm == 1:
                                result, vectors = pure_emg
                            else:
                                w = int(condition)/100
                                wave = np.sqrt(w)*line[arm] + np.sqrt(1-w)*emg
                                result, vectors = score(clean, beta, beta_power, clean_bde, wave, None, w*hpower[arm])
                                if condition == "0":
                                    pure_emg = result, vectors
                            records.append((*case, condition, mode, *result))
                            for edge in EDGES:
                                features[edge].append(vectors[edge])
            for edge, bundles in features.items():
                if session == 1:
                    bundles *= len(cases)+1
                for column, group in zip(storage[edge], zip(*bundles, strict=True), strict=True):
                    column.append(np.stack(group))
    frame = pd.DataFrame(records, columns=["subject", "session", "trial", "draw", "condition",
                                           "mode", "harmonic_beta_pct", "beta_snr_db",
                                           "bde_error_bit", "broadband_snr_db"])
    frame.to_csv(cache / f"subject_{subject:02d}.csv", index=False)
    with dest.with_suffix(".tmp").open("wb") as f:
        np.savez(f, meta=np.asarray(meta), **{f"e{edge}_x{i}": np.stack(values)
                                           for edge, groups in storage.items()
                                           for i, values in enumerate(groups)})
    dest.with_suffix(".tmp").replace(dest)
    print(f"SEED {subject:02d} completed", flush=True)
    return subject


def decode(cache, out, subject_ids):
    splits = [np.load(cache / f"subject_{s:02d}.npz", allow_pickle=False) for s in subject_ids]
    try:
        meta = np.concatenate([part["meta"] for part in splits])
        j.CASES = cases
        for edge in EDGES:
            dest = out / f"edge_{edge}"
            dest.mkdir(exist_ok=True)
            data = {"meta": meta}
            for i in range(3):
                data[f"x{i}"] = np.concatenate([part[f"e{edge}_x{i}"] for part in splits])
            j.decode(data, dest, protocols=("calibrated",))
            del data
    finally:
        for part in splits:
            part.close()


def summarize(cache, out, ids):
    from scipy.stats import t
    values = pd.concat([pd.read_csv(cache / f"subject_{s:02d}.csv", dtype={"condition": str})
                        for s in ids], ignore_index=True)
    assert len(values) == 900*len(CONDITIONS)*2
    assert values.broadband_snr_db.abs().max() < 2e-6
    assert not values.duplicated(["subject","session","trial","draw","condition","mode"]).any()
    values.to_csv(out / "trial_metrics.csv", index=False)
    columns = ["harmonic_beta_pct", "beta_snr_db", "bde_error_bit"]
    group = values.groupby(["subject", "condition", "mode"])[columns].mean()
    clean_scores = {}
    for edge in EDGES:
        dest = out / f"edge_{edge}" / "trial_predictions.csv"
        p = pd.read_csv(dest)
        assert len(p) == 450 + 900*len(CONDITIONS)*2
        p["correct"] = p.label == p.prediction
        clean_scores[str(edge)] = 100*p[p.synthesis.eq("clean")].groupby(["subject", "label"]).correct.mean().groupby(level=0).mean().mean()
        noisy = p[~p.synthesis.eq("clean")].copy()
        noisy[["condition", "mode"]] = noisy.synthesis.str.split("_", n=1, expand=True)
        key = ["subject", "condition", "mode", "label"]
        group[f"balanced_accuracy_{edge}_pct"] = 100*noisy.groupby(key).correct.mean().groupby(level=[0, 1, 2]).mean()
    group.to_csv(out / "participant_metrics.csv")
    wide = group.unstack("mode")
    keys = ["beta_snr_db","bde_error_bit",*[f"balanced_accuracy_{e}_pct" for e in EDGES]]
    samples = np.random.default_rng(20261125).integers(len(ids), size=(20_000,len(ids)))
    rows = []
    for condition in CONDITIONS:
        frame = wide.xs(condition, level="condition").sort_index()
        row = {"condition":condition}
        for name in columns + [f"balanced_accuracy_{e}_pct" for e in EDGES]:
            for mode in MODES:
                row[f"{name}_{mode}"] = frame[name][mode].mean()
        deltas = {key: frame[key]["antialias"] - frame[key]["direct"] for key in keys}
        deltas["edge45_minus_edge49_pp"] = deltas["balanced_accuracy_45_pct"]-deltas["balanced_accuracy_49_pct"]
        for key, diff in deltas.items():
            d = diff.to_numpy()
            mean = d.mean()
            lower, upper = np.quantile(d[samples].mean(axis=1), (.025,.975))
            row.update({f"{key}_aa_minus_direct":mean, f"{key}_ci95_lo":lower, f"{key}_ci95_hi":upper})
            if condition != "joint":
                half = t.ppf(1-.05/(2*len(GRID)), len(ids)-1)*d.std(ddof=1)/np.sqrt(len(ids))
                row.update({f"{key}_sim95_lo":mean-half, f"{key}_sim95_hi":mean+half})
        rows.append(row)
    table = pd.DataFrame(rows)
    table.to_csv(out / "summary.csv", index=False)
    result = {"participants": len(ids), "trials": 450, "draws_per_trial": 2,
              "nominal_snr_db": 0, "bootstrap_resamples": len(samples),
              "clean_balanced_accuracy_pct": clean_scores,
              "maximum_abs_broadband_snr_db": float(values.broadband_snr_db.abs().max()),
              "pointwise": "paired participant percentile bootstrap",
              "simultaneous": "Bonferroni paired t intervals within each endpoint's seven-grid family",
              "rows": json.loads(table.to_json(orient="records", double_precision=12))}
    (out / "summary.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("aligned", "dependencies", "code", "data", "epochs", "emg", "mapping", "geometry", "out"):
        parser.add_argument("--"+name, required=True, type=lambda s: Path(s).resolve())
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--pilot", action="store_true")
    args = parser.parse_args()
    params = (args.aligned,args.dependencies,args.code,args.epochs,args.emg,args.mapping,args.geometry)
    cache = args.out / ("pilot" if args.pilot else "cache")
    cache.mkdir(exist_ok=True, parents=True)
    initialize(*params)
    if args.pilot:
        participant(args.data, cache, 1, trial_limit=1)
        return
    ids = list(range(1,16))
    with ProcessPoolExecutor(max_workers=args.workers, initializer=initialize, initargs=params) as pool:
        list(pool.map(partial(participant,args.data,cache), ids))
    decode(cache, args.out, ids)
    summarize(cache, args.out, ids)


if __name__ == "__main__":
    main()

