# SEED mains–EMG sweep

All rows use 15 participants and 0 dB broadband calibration. Cells give Direct/AA means followed by AA minus Direct and its pointwise 95% paired participant-bootstrap interval. Each percentage denotes the nominal Direct mains share of broadband component power before mixing.

## Delivered Beta exposure and feature error

| Mains share | Direct Beta harmonic share (%) | AA Beta harmonic share (%) | Beta SNR (dB) | Beta BDE error (bit) |
| --- | ---: | ---: | --- | --- |
| 0% | 0.000 | 0.000000 | 0.54/0.54 · +0.00 [+0.00, +0.00] | 0.2165/0.2165 · +0.0000 [+0.0000, +0.0000] |
| 10% | 9.434 | 0.000000 | 0.55/0.95 · +0.40 [+0.38, +0.41] | 0.2580/0.2207 · -0.0373 [-0.0440, -0.0314] |
| 25% | 23.125 | 0.000000 | 0.61/1.68 · +1.07 [+1.04, +1.10] | 0.2631/0.2193 · -0.0438 [-0.0572, -0.0302] |
| 50% | 46.353 | 0.000001 | 0.74/3.32 · +2.58 [+2.53, +2.63] | 0.2526/0.2084 · -0.0442 [-0.0653, -0.0211] |
| 75% | 71.411 | 0.000002 | 0.93/6.22 · +5.29 [+5.23, +5.36] | 0.2282/0.1809 · -0.0473 [-0.0745, -0.0168] |
| 90% | 87.993 | 0.000006 | 1.06/10.13 · +9.07 [+8.99, +9.15] | 0.2031/0.1423 · -0.0607 [-0.0906, -0.0271] |
| 100% | 99.995 | 0.023916 | 1.16/46.09 · +44.93 [+44.92, +44.94] | 0.1772/0.0599 · -0.1173 [-0.1462, -0.0880] |
| Smooth SEED Joint | 5.304 | 0.000000 | 4.82/5.06 · +0.24 [+0.23, +0.25] | 0.1814/0.1646 · -0.0168 [-0.0189, -0.0150] |

## Fixed-decoder sensitivity

Clean balanced accuracy was 59.78% at 45 Hz and 60.22% at 49 Hz. The interaction is the 45 Hz AA advantage minus the 49 Hz AA advantage.

| Mains share | Balanced accuracy at 45 Hz (%) and difference (pp) | Balanced accuracy at 49 Hz (%) and difference (pp) | Interaction (pp) |
| --- | --- | --- | --- |
| 0% | 45.00/45.00 · +0.00 [+0.00, +0.00] | 45.67/45.67 · +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| 10% | 45.11/45.78 · +0.67 [-0.67, +2.22] | 45.33/47.56 · +2.22 [+0.44, +4.33] | -1.56 [-4.22, +0.67] |
| 25% | 44.67/46.67 · +2.00 [+0.11, +4.00] | 44.00/48.11 · +4.11 [-0.11, +9.44] | -2.11 [-7.78, +2.33] |
| 50% | 44.78/48.44 · +3.67 [+1.11, +6.67] | 43.56/48.44 · +4.89 [+0.44, +10.22] | -1.22 [-6.33, +2.89] |
| 75% | 46.00/51.11 · +5.11 [+2.22, +8.44] | 45.22/48.78 · +3.56 [-0.78, +9.00] | +1.56 [-3.44, +5.89] |
| 90% | 47.56/53.44 · +5.89 [+2.00, +10.11] | 46.78/48.67 · +1.89 [-3.56, +7.89] | +4.00 [-1.44, +9.22] |
| 100% | 52.78/57.11 · +4.33 [+0.11, +8.89] | 49.00/48.89 · -0.11 [-6.00, +5.56] | +4.44 [-0.44, +9.33] |
| Smooth SEED Joint | 49.33/49.78 · +0.44 [-1.11, +2.00] | 50.00/50.22 · +0.22 [-0.78, +1.44] | +0.22 [-1.44, +1.89] |

Pointwise intervals are descriptive. The CSV and JSON supply Bonferroni intervals for each seven-point endpoint family. The full Joint replay serves as a reference outside the grid.
