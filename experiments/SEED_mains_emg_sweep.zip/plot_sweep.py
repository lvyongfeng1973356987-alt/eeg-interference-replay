"""Plot the paired participant effects from the SEED mains/EMG sweep."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent
data = pd.read_csv(root/"summary.csv")
data = data[data.condition.ne("joint")].copy()
data["mains"] = data.condition.astype(int)

plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":8, "pdf.fonttype":42,
                     "axes.spines.top":False, "axes.spines.right":False})
fig, axes = plt.subplots(1, 3, figsize=(7.25, 2.46), sharex=True, layout="constrained")


def effect(ax, endpoint, color, marker, fill, label=None, shift=0):
    mean = data[f"{endpoint}_aa_minus_direct"]
    err = np.vstack([mean-data[f"{endpoint}_ci95_lo"], data[f"{endpoint}_ci95_hi"]-mean])
    ax.errorbar(data.mains+shift, mean, yerr=err, color=color, marker=marker,
                markerfacecolor=color if fill else "white", linewidth=1,
                markersize=4, capsize=2.2, label=label)


blue, orange = "#235989", "#a65123"
effect(axes[0], "beta_snr_db", blue, "o", True)
effect(axes[1], "bde_error_bit", blue, "o", True)
effect(axes[2], "balanced_accuracy_45_pct", blue, "o", True, "45 Hz edge", -.8)
effect(axes[2], "balanced_accuracy_49_pct", orange, "s", False, "49 Hz edge", .8)
axes[2].legend(frameon=False, fontsize=7, loc="best")
panels = (
    ("(a) Band exposure", "Beta SNR (dB)"),
    ("(b) Feature fidelity", "Beta BDE error (bit)"),
    ("(c) Decoder sensitivity", "Balanced accuracy (pp)"),
)
for ax, (title, ylabel) in zip(axes, panels, strict=True):
    ax.set_title(title, loc="left", fontweight="semibold", fontsize=8)
    ax.set_ylabel(ylabel)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xlim(-4, 106)
    ax.axhline(0, color=".55", linewidth=.75, linestyle="--", zorder=0)
    ax.grid(axis="y", color=".91", linewidth=.55, zorder=0)
fig.supylabel("AA minus Direct", fontsize=8)
fig.supxlabel("Nominal Direct broadband mains share (%)", fontsize=8)
fig.savefig(root/"mains_emg_sweep.pdf")
fig.savefig(root/"mains_emg_sweep.png", dpi=250)

