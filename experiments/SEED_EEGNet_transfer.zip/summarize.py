"""Summarize paired EEGNet and archived SVM trial predictions by SEED participant."""
import argparse
import json
from pathlib import Path
import re
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np
import pandas as pd

EDGES = (45, 49)
ARMS = ("clean","direct","antialias")
KEYS = ["subject","session","trial","draw","mode"]
SUBJECTS = list(range(1,16))
N_RESAMPLE = 20_000
BOOT_SEED = 20261125


def evaluate(frame):
    assert len(frame) == 2250
    assert not frame.duplicated(KEYS).any()
    assert set(frame.subject) == set(SUBJECTS)
    assert set(frame.session) == {2,3}
    observed = frame.groupby(["subject","mode","label"]).size()
    expected = np.where(observed.index.get_level_values("mode")=="clean",10,20)
    np.testing.assert_array_equal(observed.to_numpy(),expected)
    frame = frame.assign(correct=frame.label.eq(frame.prediction))
    group = frame.groupby(["subject","mode","label"]).correct.mean()
    return 100*group.groupby(level=[0,1]).mean().unstack().loc[SUBJECTS,list(ARMS)]


def estimate(scores,indexes):
    values = scores.to_numpy()
    assert len(values) == len(SUBJECTS)
    lo, hi = np.quantile(values[indexes].mean(axis=1), [.025,.975])
    return {"mean":float(values.mean()),"95_ci":[float(lo),float(hi)]}


def summary(scores,indexes):
    arms = {}
    advantage = {}
    for edge in EDGES:
        participant = scores[edge]
        advantage[edge] = participant.antialias-participant.direct
        arms[str(edge)] = {mode:estimate(participant[mode],indexes) for mode in ARMS}
        arms[str(edge)]["AA_minus_Direct_pp"] = estimate(advantage[edge],indexes)
    return {"edge_hz":arms,"edge_45_minus_49_pp":estimate(advantage[45]-advantage[49],indexes)}


def ledger_from_svm(path):
    return pd.read_csv(path).rename(columns={"realization":"draw","synthesis":"mode"})


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path("."))
    parser.add_argument("--archive",type=Path,required=True,help="Baseline aligned_protocol/results")
    parser.add_argument("--device",default="NVIDIA GeForce RTX 5070 Ti Laptop GPU")
    parser.add_argument("--torch-version",default="2.12.0.dev20260408+cu128")
    args=parser.parse_args()
    home=args.root
    waveform=pd.read_csv(home/"cache"/"waveform_manifest.csv")
    assert len(waveform)==1800 and waveform.broadband_snr_db.abs().max() < 2e-6
    assert waveform.injected_interference_sha256.str.fullmatch(r"[0-9a-f]{64}").all()
    expected=set(waveform[KEYS].itertuples(index=False,name=None))
    data, selections, clean_folds = {}, [], {}
    participant = {}
    trials = []
    for edge in EDGES:
        dest = home/"results"/f"edge_{edge}"
        e = pd.concat([pd.read_csv(dest/f"s{who:02d}"/"predictions.csv") for who in SUBJECTS],
                      ignore_index=True)
        svm = ledger_from_svm(args.archive/f"line_{edge}"/"trial_predictions.csv")
        assert set(e[KEYS].itertuples(index=False,name=None))==set(svm[KEYS].itertuples(index=False,name=None))
        assert set(e.loc[e.draw.ne(0),KEYS].itertuples(index=False,name=None))==expected
        assert (e[["p_neg","p_neutral","p_pos"]].to_numpy().argmax(1)-1==e.prediction.to_numpy()).all()
        np.testing.assert_allclose(e[["p_neg","p_neutral","p_pos"]].sum(axis=1),1,atol=1e-6,rtol=0)
        for who in SUBJECTS:
            folder=dest/f"s{who:02d}"
            d=json.loads((folder/"training.json").read_text(encoding="utf-8"))
            fit,val,tune=(set(d[k]) for k in ("fit","validation","tune_fit"))
            assert fit==set(SUBJECTS)-{who} and val|tune==fit and not val&tune
            assert len(val)==3 and len(tune)==11
            assert who==d["test"] and edge==d["edge_hz"]
            assert d["validation_trial_nll"][d["best_epoch"]-1] <= min(d["validation_trial_nll"])+1e-5
            assert (folder/"weights.pt").stat().st_size > 0
            key=(d["seed"],d["validation"],d["tune_fit"])
            if edge==45:
                clean_folds[who]=key
            else:
                assert clean_folds[who]==key
            selections.append({"edge_hz":edge,"subject":who,
                               "epoch":d["best_epoch"],"epochs_run":len(d["validation_trial_nll"]),
                               "validation_subjects":" ".join(map(str,d["validation"])),
                               "train_subjects":" ".join(map(str,d["fit"]))})
        trials.append(e.assign(edge_hz=edge))
        participant[edge]=evaluate(e)
        data[edge]=evaluate(svm)

    indices=np.random.default_rng(BOOT_SEED).integers(len(SUBJECTS),size=(N_RESAMPLE,len(SUBJECTS)))
    cnn_results=summary(participant,indices)
    svm_results=summary(data,indices)
    np.testing.assert_allclose(
        [svm_results["edge_45_minus_49_pp"]["mean"],*svm_results["edge_45_minus_49_pp"]["95_ci"]],
        [14.77777777777778,6.111111111111111,24.111111111111107],atol=1e-10)
    records=[]
    for name, table in (("EEGNet-8,2",participant),("SVM",data)):
        for edge, scores in table.items():
            for who, score in scores.iterrows():
                records.append({"model":name,"upper_edge_hz":edge,"subject":who,
                                **score.to_dict(),"aa_minus_direct_pp":score.antialias-score.direct})
    pd.DataFrame(records).to_csv(home/"participant_scores.csv",index=False)
    pd.concat(trials,ignore_index=True).to_csv(home/"trial_predictions.csv",index=False)
    pd.DataFrame(selections).to_csv(home/"training_selections.csv",index=False)
    final={"dataset":"SEED","participants":len(SUBJECTS),"clean_trials_per_fold":420,
           "test_trials_per_fold":30,"noisy_replays_per_arm":900,"nominal_input_snr_db":0,
           "device":args.device,"torch":args.torch_version,
           "inference":{"method":"exploratory paired participant percentile bootstrap",
                        "resamples":N_RESAMPLE,"seed":BOOT_SEED,
                        "max_absolute_input_calibration_error_db":float(waveform.broadband_snr_db.abs().max())},
           "eegnet":cnn_results,"archived_svm":svm_results}
    (home/"summary.json").write_text(json.dumps(final,indent=2)+"\n",encoding="utf-8")
    summary_rows=[]
    def interval(z):
        return f"{z['mean']:+.2f} [{z['95_ci'][0]:+.2f}, {z['95_ci'][1]:+.2f}]"
    text=["# SEED isolated-mains decoder transfer", "",
          "Balanced accuracy is in percent. Paired differences are in percentage points. Brackets give exploratory 95% paired participant-bootstrap intervals (20,000 resamples, 15 participants).",
          "",
          "| Model | Upper edge | Clean | Direct | AA | AA − Direct (pp) |",
          "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for name, r in (("EEGNet-8,2",cnn_results),("Archived SVM",svm_results)):
        for edge, z in r["edge_hz"].items():
            row={"model":name,"edge_hz":int(edge),**{mode:z[mode]["mean"] for mode in ARMS},
                 "aa_minus_direct_pp":z["AA_minus_Direct_pp"]["mean"],
                 "lo95_pp":z["AA_minus_Direct_pp"]["95_ci"][0],
                 "hi95_pp":z["AA_minus_Direct_pp"]["95_ci"][1]}
            summary_rows.append(row)
            text.append(f"| {name} | {edge} Hz | {row['clean']:.2f} | {row['direct']:.2f} | {row['antialias']:.2f} | {interval(z['AA_minus_Direct_pp'])} |")
    text.extend(["","## 45 Hz minus 49 Hz AA advantage","",
                 f"- EEGNet-8,2: {interval(cnn_results['edge_45_minus_49_pp'])} pp.",
                 f"- Archived SVM: {interval(svm_results['edge_45_minus_49_pp'])} pp.",""])
    (home/"results.md").write_text("\n".join(text),encoding="utf-8")
    pd.DataFrame(summary_rows).to_csv(home/"summary.csv",index=False)
    print(f"Summarized {sum(len(x) for x in trials)} EEGNet trial predictions across {len(EDGES)} band edges.")


if __name__=="__main__":
    main()

