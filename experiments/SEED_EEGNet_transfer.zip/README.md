# EEGNet transfer test on the SEED isolated-mains replay

## Input and operating point

The experiment uses the SEED release at 200 Hz. Its first 60 s are resampled to 128 Hz with the same polyphase conversion as the archived smooth-gain SVM line comparison. The archived `aligned_protocol/replay.py` generates the same Direct and AA waveforms with the same smooth spatial gains, original timing sequence, per-trial phases and two realizations. Gain is set to 0 dB against each clean release trial before analysis filtering. The 4–45 Hz and 4–49 Hz arms share those injected waveforms. The replay includes no added notch.

Each arm filters the full trial once with a Butterworth bandpass with a fifth-order prototype (five second-order sections), forward and backward with odd extension. The nominal forward–backward gain at 50 Hz is −32.08 dB for the 45 Hz edge and −10.21 dB for the 49 Hz edge. Both preserve 22 and 28 Hz to 0.01 dB. Each participant's 15 unlabeled clean Session 1 trials supply per-channel time-domain means and standard deviations separately for each filter. The means and standard deviations stay fixed for all later arms. Each trial contributes 13 nonoverlapping 512-sample windows beginning at sample 640, using zero-based indexing.

The archived SVM uses per-band variance and spatial features and its own filter-state convention. Thus the comparison examines transfer to an EEGNet waveform pipeline across the two band edges. A model-family comparison at a common waveform front end would answer a separate question.

## EEGNet training and inference

EEGNet-8,2 uses eight 64-sample temporal kernels, depth multiplier two, 16 separable output filters, length-16 depthwise separable temporal kernels, average pooling by four and eight, ELU and dropout 0.5. The depthwise spatial and classifier max norms are 1 and 0.25, respectively. The loss is window-level cross entropy, with Adam at learning rate 0.001 and batch size 128. In each outer fold the 14 training subjects are split into 11 tuning subjects and three validation subjects, with the same seed and subject groups at both edges. During the tuning fit, a maximum of 20 epochs with patience five selects the epoch by validation trial-level negative log likelihood after probability pooling. Each final model starts from the same initialization seed and trains on all 14 subjects' clean Sessions 2–3 for the selected number of epochs. For the held-out subject, the independent Session 1 channel statistics are used at inference. The fitting and epoch selection use the other participants.

At each edge, the same fold checkpoint scores the held-out subject's clean, Direct and AA trials. The model averages window softmax probabilities within each trial. Balanced accuracy is the mean class recall within each participant and then averaged across participants. Both draws contribute to each noisy arm. Participant-level paired bootstrap resampling (20,000 draws, common index matrix across all arms and edges) gives exploratory 95% percentile intervals. The transfer contrast is the difference between the 45 Hz AA-minus-Direct advantage and the 49 Hz advantage.

## Reproduce

Use the external data and archive sources named in the manuscript's `aligned_protocol` and `instantaneous_replay` directories and the pinned source at commit `6d5edcf11697e1c4e3ec1cbe7a601524f028a0a6`. The scripts' `--help` options list each input path. `prepare_local.ps1` and `audit_local.ps1` record the paths used for this run.

1. Run `prepare.py` to build the analysis cache from the external data. `waveform_manifest.csv` records the SHA-256 of every actual injected interference array before band filtering. Use a fresh cache when the inputs or settings change.
2. Run `python train_eegnet.py --cache cache --out results`. Each completed fold writes its weights, prediction ledger and clean-only validation trace. Use a fresh results directory if the model or training settings change.
3. Run `summarize.py --archive PATH_TO/aligned_protocol/results` for trial, participant and aggregate output. `audit_svm.py` independently rebuilds the historical 49 Hz SVM using the same injected signals and checks it against the frozen trial predictions. Use `audit_local.ps1` to replay the check with the local paths.
4. Inspect `results.md`, `summary.csv` and `summary.json`. The archive contains model weights and ledgers. The results archive carries trial keys and waveform hashes, with the EEG arrays and normalization cache kept locally. The included SVM ledgers allow the summary to be regenerated after extraction with python summarize.py --archive archived_svm.

Runtime: Python 3.12.10, NumPy 2.4.4, SciPy 1.17.1, pandas 3.0.2, scikit-learn 1.8.0, PyTorch 2.12.0.dev20260408+cu128 on an NVIDIA GeForce RTX 5070 Ti Laptop GPU. GPU training and inference use BF16 autocast, FP32 optimizer state and deterministic Torch algorithms, with fold seeds `20261126 + subject`.

