"""Prepare EEGNet windows from the exact archived smooth-gain isolated-line replay."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from hashlib import sha256
from pathlib import Path
import re
import sys

import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.signal import butter, resample_poly, sosfiltfilt

EDGES = (45, 49)
MODES = ("direct", "antialias")
CONTROL_DIGEST = "ce3f5b16284ed13a5f415b6c3d18bb704c99a8c3b752bd6ad5e69781a61d34ec"


def initialize(aligned, dependencies, code, epochs, emg, mapping, control, geometry):
    global replay, j, sos, starts
    sys.path[:0] = [str(aligned), str(dependencies)]
    import replay
    replay.initialize(code, epochs, emg, mapping, control, geometry)
    j = replay.n.replay.j
    sos = {edge: butter(5, (4, edge), fs=128, btype="bandpass", output="sos") for edge in EDGES}
    starts = np.arange(j.REF, j.T-j.WINDOW+1, j.WINDOW)
    assert len(starts) == 13


def windows(z, center, scale):
    data = [(z[..., start:start+j.WINDOW]-center)/scale for start in starts]
    return np.stack(data, axis=0).astype("float32")


def band(signal, edge):
    return sosfiltfilt(sos[edge], signal, axis=-1, padtype="odd")


def subject(data, destination, who, limit=None):
    out = destination/f"s{who:02d}"
    out.mkdir(exist_ok=True)
    marker = out/"waveforms.csv"
    if marker.is_file():
        return who
    paths = sorted(p for p in data.glob(f"{who}_*.mat") if re.fullmatch(r"\d+_\d+\.mat", p.name))
    labels = loadmat(data/"label.mat")["label"].ravel().astype(int)
    assert len(paths) == 3 and set(labels) == {-1, 0, 1} and len(labels) == 15
    calibration = {edge: [] for edge in EDGES}
    clean_data = {edge: [] for edge in EDGES}
    noisy_data = {edge: [] for edge in EDGES}
    keys, ledger = [], []
    for session, path in enumerate(paths, 1):
        for trial, label in enumerate(labels[:limit], 1):
            if trial == 1:
                mat = loadmat(path)
            eeg = next(v for k, v in mat.items() if re.search(rf"eeg{trial}$", k))
            clean = resample_poly(eeg[:, :12000].astype("float32"), 16, 25, axis=-1)
            assert clean.shape == (62, 7680)
            if session == 1:
                for edge in EDGES:
                    calibration[edge].append(band(clean, edge))
                continue
            keys.append((who, session, trial, label))
            signals = []
            for draw in j.REALIZATIONS:
                pairs = replay.generate(replay.primary.controls["recorded"], replay.legacy_epochs,
                                        (who, session, trial, draw), smooth=False)
                for mode, (_, _, line) in zip(MODES, pairs, strict=True):
                    gain = j.amount(clean, line, 0)
                    residual = gain*line
                    error = 10*np.log10(j.power(clean)/j.power(residual))
                    assert abs(error) < 2e-6
                    signals.append(clean+residual)
                    digest = sha256(np.asarray(residual, dtype="<f4", order="C").tobytes()).hexdigest()
                    ledger.append((who, session, trial, draw, mode, error, digest))
            for edge in EDGES:
                if session == 2 and trial == 1:
                    reference = np.concatenate(calibration[edge], axis=-1)
                    center = reference.mean(axis=-1, keepdims=True)
                    scale = reference.std(axis=-1, keepdims=True)
                    assert np.all(scale > 1e-6)
                    calibration[edge] = center, scale
                    np.savez(out/f"norm_{edge}.npz", center=center, scale=scale)
                center, scale = calibration[edge]
                clean_data[edge].append(windows(band(clean, edge), center, scale))
                noisy_data[edge].append(np.stack([windows(band(wave, edge), center, scale) for wave in signals]))
    np.save(out/"trials.npy", np.array(keys))
    for edge in EDGES:
        for key, values in (("clean", clean_data), ("noisy", noisy_data)):
            data_array = np.stack(values[edge])
            assert np.isfinite(data_array).all()
            np.save(out/f"{key}_{edge}.npy", data_array)
    records = pd.DataFrame(ledger, columns=["subject", "session", "trial", "draw", "mode",
                                            "broadband_snr_db", "injected_interference_sha256"])
    records.to_csv(out/"waveforms.tmp", index=False)
    (out/"waveforms.tmp").replace(marker)
    print(f"Waveforms SEED {who:02d} complete", flush=True)
    return who


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    keys = ("aligned", "dependencies", "code", "epochs", "emg", "mapping", "control", "geometry")
    for key in (*keys, "data", "out"):
        parser.add_argument("--"+key, required=True, type=lambda s: Path(s).resolve())
    parser.add_argument("--workers", default=8, type=int)
    parser.add_argument("--pilot", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True, parents=True)
    assert sha256(args.control.read_bytes()).hexdigest() == CONTROL_DIGEST
    params = tuple(getattr(args,k) for k in keys)
    if args.pilot:
        initialize(*params)
        subject(args.data,args.out,1,limit=2)
        return
    with ProcessPoolExecutor(max_workers=args.workers,initializer=initialize,initargs=params) as pool:
        list(pool.map(partial(subject,args.data,args.out),range(1,16)))
    records = pd.concat([pd.read_csv(args.out/f"s{i:02d}/waveforms.csv") for i in range(1,16)],
                        ignore_index=True)
    assert len(records) == 1800
    assert not records.duplicated(["subject","session","trial","draw","mode"]).any()
    assert records.injected_interference_sha256.nunique() == 1800
    records.to_csv(args.out/"waveform_manifest.csv", index=False)


if __name__ == "__main__":
    main()

