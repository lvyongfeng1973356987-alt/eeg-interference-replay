"""Independently replay the SVM comparator at 49 Hz and verify CNN interference IDs."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from hashlib import sha256
from pathlib import Path
import json
import re

import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.signal import resample_poly

import prepare


def audit_subject(data, manifest, who):
    j, replay = prepare.j, prepare.replay
    trials = sorted(p for p in data.glob(f"{who}_*.mat") if re.fullmatch(r"\d+_\d+\.mat",p.name))
    labels = loadmat(data/"label.mat")["label"].ravel().astype(int)
    hashes = pd.read_csv(manifest).set_index(["subject","session","trial","draw","mode"])
    meta, vectors = [], [[],[],[]]
    for session, path in enumerate(trials,1):
        mat = loadmat(path)
        for trial, label in enumerate(labels,1):
            clean = resample_poly(next(v for k,v in mat.items() if re.search(rf"eeg{trial}$",k))[:,:12000].astype("float32"),16,25,axis=-1)
            noise = []
            if session != 1:
                for draw in j.REALIZATIONS:
                    arms = replay.generate(replay.primary.controls["recorded"],replay.legacy_epochs,
                                           (who,session,trial,draw))
                    for mode, (_,_,line) in zip(prepare.MODES,arms,strict=True):
                        key = (who,session,trial,draw,mode)
                        digest=sha256(np.asarray(j.amount(clean,line,0)*line,dtype="<f4",order="C").tobytes()).hexdigest()
                        assert hashes.loc[key,"injected_interference_sha256"]==digest, key
                        noise.append(line)
            features, _ = j.features(clean,noise)
            for col, signal in zip(vectors,features,strict=True):
                col.append(signal.astype("float32") if noise else np.repeat(signal.astype("float32"),5,axis=0))
            meta.append((who,session,trial,label))
    print(f"Audited input and SVM features for SEED {who:02d}",flush=True)
    return np.asarray(meta),[np.stack(v) for v in vectors]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    params=("aligned","dependencies","code","epochs","emg","mapping","control","geometry")
    for key in (*params,"data","cache","archived","out"):
        parser.add_argument("--"+key,type=lambda s:Path(s).resolve(),required=True)
    parser.add_argument("--workers",type=int,default=6)
    a=parser.parse_args()
    args=tuple(getattr(a,p) for p in params)
    prepare.initialize(*args)
    a.out.mkdir(exist_ok=True,parents=True)
    with ProcessPoolExecutor(max_workers=a.workers,initializer=prepare.initialize,initargs=args) as pool:
        entries=list(pool.map(partial(audit_subject,a.data,a.cache/"waveform_manifest.csv"),range(1,16)))
    cache={"meta":np.concatenate([m for m,_ in entries])}
    for i in range(3):
        cache[f"x{i}"]=np.concatenate([v[i] for _,v in entries])
    prepare.j.decode(cache,a.out,protocols=("calibrated",))
    open_test=pd.read_csv(a.out/"trial_predictions.csv")
    archive=pd.read_csv(a.archived/"trial_predictions.csv")
    pd.testing.assert_frame_equal(open_test,archive)
    selcols=["protocol","outer_subject","feature","kernel","C"]
    pd.testing.assert_frame_equal(pd.read_csv(a.out/"clean_inner_selection.csv")[selcols],
                                  pd.read_csv(a.archived/"clean_inner_selection.csv")[selcols])
    stats={"injected_waveforms_matched_by_sha256":1800,"archived_49_hz_svm_predictions_matched":len(archive),
           "archived_49_hz_svm_clean_model_selections_matched":15}
    (a.out/"verification.json").write_text(json.dumps(stats,indent=2)+"\n",encoding="utf-8")
    print(stats,flush=True)


if __name__=="__main__":
    main()

