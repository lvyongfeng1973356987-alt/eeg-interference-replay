"""Package the reproducible ledgers, code and checkpoints, omitting EEG arrays."""
from hashlib import sha256
from pathlib import Path
import argparse
from zipfile import ZipFile, ZIP_DEFLATED


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    with ZipFile(root/"SEED_EEGNet_transfer.zip","w",compression=ZIP_DEFLATED) as z:
        included = {}
        local = ["README.md","prepare.py","prepare_local.ps1","train_eegnet.py","summarize.py",
                 "audit_svm.py","audit_local.ps1","package_results.py","summary.json","summary.csv",
                 "results.md","participant_scores.csv","trial_predictions.csv","training_selections.csv",
                 "cache/waveform_manifest.csv","svm_replay/verification.json",
                 "svm_replay/clean_inner_selection.csv","svm_replay/trial_predictions.csv"]
        for name in local:
            included[name]=root/name
        for edge in (45,49):
            archived = args.archive/f"line_{edge}"/"trial_predictions.csv"
            included[f"archived_svm/line_{edge}/trial_predictions.csv"]=archived
            for who in range(1,16):
                for name in ("weights.pt","training.json","predictions.csv"):
                    key=f"results/edge_{edge}/s{who:02d}/{name}"
                    included[key]=root/key
        sums=[]
        for name, path in sorted(included.items()):
            content=path.read_bytes()
            z.writestr(name,content)
            sums.append(f"{sha256(content).hexdigest()}  {name}")
        z.writestr("SHA256SUMS","\n".join(sums)+"\n")
    with ZipFile(root/"SEED_EEGNet_transfer.zip") as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(included)|{"SHA256SUMS"}
        for line in z.read("SHA256SUMS").decode().splitlines():
            hs, name = line.split("  ", maxsplit=1)
            assert sha256(z.read(name)).hexdigest()==hs
        print(f"Verified {len(included)} files")


if __name__ == "__main__":
    main()

