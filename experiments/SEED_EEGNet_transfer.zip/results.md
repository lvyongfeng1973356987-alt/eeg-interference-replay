# SEED isolated-mains decoder transfer

Balanced accuracy is in percent. Paired differences are in percentage points. Brackets give exploratory 95% paired participant-bootstrap intervals (20,000 resamples, 15 participants).

| Model | Upper edge | Clean | Direct | AA | AA − Direct (pp) |
| --- | ---: | ---: | ---: | ---: | ---: |
| EEGNet-8,2 | 45 Hz | 50.44 | 38.78 | 50.67 | +11.89 [+5.22, +19.33] |
| EEGNet-8,2 | 49 Hz | 47.56 | 39.22 | 46.33 | +7.11 [+2.11, +12.56] |
| Archived SVM | 45 Hz | 58.89 | 43.44 | 59.11 | +15.67 [+6.67, +25.22] |
| Archived SVM | 49 Hz | 59.33 | 34.56 | 35.44 | +0.89 [-1.89, +4.00] |

## 45 Hz minus 49 Hz AA advantage

- EEGNet-8,2: +4.78 [+0.11, +9.11] pp.
- Archived SVM: +14.78 [+6.11, +24.11] pp.
