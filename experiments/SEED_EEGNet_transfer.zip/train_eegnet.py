"""Train a clean-only EEGNet-8,2 in participant-held-out SEED replays."""
import argparse
from pathlib import Path
import json
import os
from time import perf_counter

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F

EDGES = (45, 49)
ARMS = ((0, "clean"), (1, "direct"), (1, "antialias"),
        (2, "direct"), (2, "antialias"))
N_CLASSES = 3
CHANNELS = 62
WINDOW = 512
WINDOWS_PER_TRIAL = 13
SEED = 20261126
BATCH = 128
MAX_EPOCHS = 20
PATIENCE = 5
MINIMUM_EPOCHS = 5


class EEGNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.temporal = nn.Conv2d(1, 8, (1, 64), bias=False)
        self.temporal_bn = nn.BatchNorm2d(8, momentum=.01, eps=.001)
        self.spatial = nn.Conv2d(8, 16, (CHANNELS, 1), groups=8, bias=False)
        self.spatial_bn = nn.BatchNorm2d(16, momentum=.01, eps=.001)
        self.depthwise = nn.Conv2d(16, 16, (1, 16), groups=16, bias=False)
        self.pointwise = nn.Conv2d(16, 16, 1, bias=False)
        self.separable_bn = nn.BatchNorm2d(16, momentum=.01, eps=.001)
        self.dropout = nn.Dropout(.5)
        self.classify = nn.Linear(16*(WINDOW//32), N_CLASSES)
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
        self.project()

    @torch.no_grad()
    def project(self):
        self.spatial.weight.renorm_(2, 0, 1)
        self.classify.weight.renorm_(2, 0, .25)

    def forward(self, wave):
        features = self.temporal_bn(self.temporal(F.pad(wave, (31, 32, 0, 0))))
        features = self.spatial_bn(self.spatial(features))
        features = self.dropout(F.avg_pool2d(F.elu(features), (1, 4)))
        features = self.pointwise(self.depthwise(F.pad(features, (7, 8, 0, 0))))
        features = self.separable_bn(features)
        features = self.dropout(F.avg_pool2d(F.elu(features), (1, 8)))
        return self.classify(features.flatten(1))


def setup(device):
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = False
        assert torch.cuda.is_bf16_supported()


def model_for(device, seed):
    torch.manual_seed(seed)
    model = EEGNet().to(device=device, memory_format=torch.channels_last)
    return model, torch.optim.Adam(model.parameters(), lr=.001, foreach=False)


def training_epoch(model, optimizer, x, y, indexes):
    model.train()
    order = torch.randperm(len(indexes), device=indexes.device)
    for batch in indexes[order].split(BATCH):
        optimizer.zero_grad(set_to_none=True)
        wave = x[batch].contiguous(memory_format=torch.channels_last)
        with torch.autocast(device_type=x.device.type, dtype=torch.bfloat16, enabled=x.is_cuda):
            loss = F.cross_entropy(model(wave), y[batch])
        loss.backward()
        optimizer.step()
        model.project()


@torch.inference_mode()
def predict(model, waves):
    assert waves.shape[-4:] == (WINDOWS_PER_TRIAL, 1, CHANNELS, WINDOW)
    model.eval()
    batches = []
    views = waves.reshape(-1, 1, CHANNELS, WINDOW)
    for wave in views.split(BATCH):
        wave = wave.contiguous(memory_format=torch.channels_last)
        with torch.autocast(device_type=wave.device.type, dtype=torch.bfloat16, enabled=wave.is_cuda):
            logits = model(wave)
        batches.append(logits.float().softmax(1))
    return torch.cat(batches).reshape(*waves.shape[:-4], WINDOWS_PER_TRIAL, N_CLASSES).mean(dim=-2)


def clean_dataset(cache, edge, device):
    subjects = range(1,16)
    keys, samples = [], []
    for who in subjects:
        folder = cache/f"s{who:02d}"
        keys.append(np.load(folder/"trials.npy"))
        samples.append(np.load(folder/f"clean_{edge}.npy"))
    meta = np.concatenate(keys)
    assert meta.shape == (450,4)
    assert np.array_equal(np.unique(meta[:,0]), np.arange(1,16))
    assert np.all(np.isin(meta[:,1],[2,3]))
    assert np.array_equal(np.unique(meta[:,3]), np.array([-1,0,1]))
    clean = torch.from_numpy(np.concatenate(samples)).to(device).unsqueeze(2)
    y = torch.as_tensor(meta[:,3]+1, dtype=torch.long, device=device)
    return meta, clean, y


def window_indexes(trial_index, device):
    x = WINDOW_INDEX[None,:]+trial_index[:,None]*WINDOWS_PER_TRIAL
    return torch.as_tensor(x.ravel(),device=device)


WINDOW_INDEX = np.arange(WINDOWS_PER_TRIAL)


def train_fold(cache, out, edge, who, meta, clean, y, max_epochs):
    device = clean.device
    seed = SEED + who
    subgroup_seed = np.random.default_rng(seed)
    candidates = np.unique(meta[meta[:,0] != who,0])
    validation = np.sort(subgroup_seed.choice(candidates,3,replace=False))
    tuning_ids = np.setdiff1d(candidates, validation)
    tune_idx = np.flatnonzero(np.isin(meta[:,0],tuning_ids))
    val_idx = np.flatnonzero(np.isin(meta[:,0],validation))
    fit_idx = np.flatnonzero(np.isin(meta[:,0],candidates))
    test_idx = np.flatnonzero(meta[:,0]==who)
    assert (len(tune_idx),len(val_idx),len(fit_idx),len(test_idx)) == (330,90,420,30)
    assert np.intersect1d(tune_idx,val_idx).size == 0

    x = clean.flatten(0,1)
    targets = y.repeat_interleave(WINDOWS_PER_TRIAL)
    tune_windows = window_indexes(tune_idx, device)
    fit_windows = window_indexes(fit_idx, device)
    model, opt = model_for(device, seed)
    best_loss, best_epoch = float("inf"), 0
    scores = []
    for epoch in range(1,max_epochs+1):
        training_epoch(model,opt,x,targets,tune_windows)
        val_prob = predict(model,clean[val_idx])
        nll = F.nll_loss(val_prob.clamp_min(1e-8).log(),y[val_idx]).item()
        assert np.isfinite(nll)
        scores.append(nll)
        if nll < best_loss - 1e-5:
            best_loss, best_epoch = nll, epoch
        if epoch >= MINIMUM_EPOCHS and epoch-best_epoch >= PATIENCE:
            break
    model, opt = model_for(device,seed)
    for _ in range(best_epoch):
        training_epoch(model,opt,x,targets,fit_windows)

    noisy = np.load(cache/f"s{who:02d}"/f"noisy_{edge}.npy")
    noisy = torch.from_numpy(noisy).to(device).unsqueeze(3)
    probs = torch.cat((predict(model,clean[test_idx])[:,None,:],
                       predict(model,noisy)),dim=1).cpu().numpy()
    np.testing.assert_allclose(probs.sum(axis=-1),1, atol=1e-6, rtol=0)

    fold = out/f"edge_{edge}"/f"s{who:02d}"
    fold.mkdir(exist_ok=True, parents=True)
    records = []
    for row, prob in zip(meta[test_idx],probs,strict=True):
        for (draw,arm), val in zip(ARMS,prob,strict=True):
            records.append((*row,draw,arm,int(np.argmax(val)-1),*map(float,val)))
    pd.DataFrame(records, columns=["subject","session","trial","label","draw","mode","prediction",
                                    "p_neg","p_neutral","p_pos"]).to_csv(fold/"predictions.csv",index=False)
    torch.save({k:v.cpu() for k,v in model.state_dict().items()},fold/"weights.pt")
    details = {"edge_hz":edge,"test":who,"seed":seed,"fit":candidates.tolist(),
               "validation":validation.tolist(),"tune_fit":tuning_ids.tolist(),"best_epoch":best_epoch,
               "validation_trial_nll":scores}
    (fold/"training.tmp").write_text(json.dumps(details,indent=2)+"\n",encoding="utf-8")
    (fold/"training.tmp").replace(fold/"training.json")
    correct = ((probs[:,0,:].argmax(1)-1)==meta[test_idx,3]).mean()
    print(f"EEGNet {edge} Hz, subject {who:02d}: selected {best_epoch}/{len(scores)} epochs, clean BA {100*correct:.2f}%",flush=True)


def benchmark(device):
    model, opt = model_for(device, SEED)
    x=torch.randn((BATCH*10,1,CHANNELS,WINDOW), device=device)
    y=torch.arange(len(x),device=device)%3
    idx=torch.arange(len(x),device=device)
    training_epoch(model,opt,x,y,idx)
    if device.type == "cuda":
        torch.cuda.synchronize()
    start=perf_counter()
    training_epoch(model,opt,x,y,idx)
    if device.type == "cuda":
        torch.cuda.synchronize()
    print(f"10 training batches: {perf_counter()-start:.3f}s",flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache",type=Path,default=Path("cache"))
    parser.add_argument("--out",type=Path,default=Path("results"))
    parser.add_argument("--edge",type=int,choices=EDGES)
    parser.add_argument("--benchmark",action="store_true")
    parser.add_argument("--device",default="cuda")
    args=parser.parse_args()
    device=torch.device(args.device)
    setup(device)
    if args.benchmark:
        benchmark(device)
        return
    for edge in (args.edge,) if args.edge else EDGES:
        meta, clean, y = clean_dataset(args.cache,edge,device)
        for who in range(1,16):
            if not (args.out/f"edge_{edge}"/f"s{who:02d}"/"training.json").is_file():
                train_fold(args.cache,args.out,edge,who,meta,clean,y,MAX_EPOCHS)
        del clean,y
        if device.type == "cuda":
            torch.cuda.empty_cache()


if __name__=="__main__":
    main()

